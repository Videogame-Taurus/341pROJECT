import React from "react";
import "./style.css";

export const Login = () => {
  return (
    <div className="login">
      <div className="div">
        <div className="text-wrapper">Login</div>
        <div className="text-wrapper-2">Password:</div>
        <img className="rectangle" alt="Rectangle" src="/img/rectangle-5.svg" />
        <img className="img" alt="Rectangle" src="/img/rectangle-5.svg" />
        <div className="text-wrapper-3">Username:</div>
        <div className="overlap-group">
          <img className="rectangle-2" alt="Rectangle" src="/img/rectangle-8.png" />
          <div className="text-wrapper-4">SYNC SPACE</div>
        </div>
        <img className="rectangle-3" alt="Rectangle" src="/img/rectangle-9.png" />
        <div className="overlap">
          <div className="text-wrapper-5">Login</div>
        </div>
        <div className="div-wrapper">
          <div className="text-wrapper-6">Forgot password</div>
        </div>
        <div className="overlap-2">
          <div className="text-wrapper-7">Sign up</div>
        </div>
      </div>
    </div>
  );
};
